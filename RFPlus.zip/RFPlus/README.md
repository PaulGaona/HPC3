
# RFPlus

<!-- badges: start -->
<!-- badges: end -->

The goal of RFPlus is to ...

## Installation

You can install the development version of RFPlus from [GitHub](https://github.com/) with:

``` r
# install.packages("devtools")
devtools::install_github("tiffanymtang/RFPlus")
```

## Example

This is a basic example which shows you how to solve a common problem:

``` r
library(RFPlus)
## basic example code
```

